import 'dart:convert';
import 'dart:io';

import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

class VidplerPop extends StatefulWidget {
  final String urx;

  const VidplerPop({super.key, required this.urx});
  @override
  _VidplerPopState createState() => _VidplerPopState();
}

class _VidplerPopState extends State<VidplerPop> {
  ChewieController? _chewieController;

  Future<void> initializePlayer() async {
    final tp = File(widget.urx + ".ts");

    print("---->");
    print(await tp.length());
    print("---->");
    final _videoPlayerController1 = VideoPlayerController.file(tp);

    print("object");

    await _videoPlayerController1.initialize();

    print("object");

    _chewieController =
        ChewieController(videoPlayerController: _videoPlayerController1);

    print("object");

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    initializePlayer();
  }

  @override
  void dispose() {
    _chewieController?.videoPlayerController.dispose();
    _chewieController?.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xff071427),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Align(
          alignment: Alignment.topRight,
          child: IconButton(
              onPressed: () {
                _chewieController?.pause();

                Navigator.pop(context);
              },
              icon: Icon(
                Icons.close,
                color: Colors.white,
              )),
        ),
        _chewieController != null
            ? AspectRatio(
                aspectRatio: 16 / 9,
                child: Chewie(controller: _chewieController!))
            : Image.asset(
                "assets/loader.gif",
                height: 100,
                width: 100,
              ),
      ]),
    );
  }
}

class DownloadedPage extends StatefulWidget {
  @override
  _DownloadedState createState() => _DownloadedState();
}

class _DownloadedState extends State<DownloadedPage> {
  List<String> videoUrls = [];

  String fgh = "";

  String pat = "";

  SharedPreferences? prefs;

  Future<void> rtx() async {
    Directory appDir = await getApplicationDocumentsDirectory();

    pat = appDir.path;

    print(pat);

    prefs = await SharedPreferences.getInstance();
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    rtx();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final double widthx = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xff071427),
          foregroundColor: Colors.white,
          title: Text('Downloaded Videos'),
        ),
        body: Column(
          children: [
            Container(
              height: 1,
              width: widthx,
              color: Colors.white,
            ),
            Expanded(
              child: ListView.builder(
                itemCount: (prefs?.getStringList("download") ?? []).length,
                itemBuilder: (context, index) {
                  Map<String, dynamic> dtx = jsonDecode(prefs?.getString(
                          prefs?.getStringList("download")![index] ?? "{}") ??
                      "{}");

                  print(dtx);

                  return Padding(
                    padding: const EdgeInsets.only(top: 10, left: 10),
                    child: InkWell(
                      onTap: () {
                        // showDialog(
                        //   barrierDismissible: false,
                        //   context: context,
                        //   builder: (context) {
                        //     return VidplerPop(
                        //       urx: pat + "/" + dtx["_id"],
                        //     );
                        //   },
                        // );

                        showBottomSheet(
                          backgroundColor: const Color(0xff071427),
                          context: context,
                          builder: (context) => VidplerPop(
                            urx: pat + "/" + dtx["_id"],
                          ),
                        );
                      },
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                                child: Image.file(
                                  File(pat + "/" + dtx["_id"] + ".jpg"),
                                  width: 120,
                                )),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: widthx - 150,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "${dtx["TITLE"]}",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                  Text("${dtx["GENRE"]} | ${dtx["DURATION"]}",
                                      style: TextStyle(
                                          fontSize: 13,
                                          color:
                                              Color.fromARGB(255, 132, 9, 0))),
                                  Row(
                                    children: [
                                      ...List.generate(5, (index) {
                                        return Icon(
                                          dtx["xstar"] > index
                                              ? Icons.star_rate
                                              : Icons.star_border_outlined,
                                          color:
                                              Color.fromARGB(255, 255, 149, 10),
                                          size: 16,
                                        );
                                      }),
                                      IconButton(
                                          onPressed: () async {
                                            final op = prefs?.getStringList(
                                                    "download") ??
                                                [];

                                            await File(pat +
                                                    "/" +
                                                    dtx["_id"] +
                                                    ".jpg")
                                                .delete();
                                            await File(pat +
                                                    "/" +
                                                    dtx["_id"] +
                                                    ".ts")
                                                .delete();

                                            op.remove("${dtx["_id"]}");

                                            await prefs?.setStringList(
                                                "download", op);

                                            setState(() {});
                                          },
                                          icon: Icon(
                                            Icons.delete_forever,
                                            color: Colors.red,
                                          ))
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ]),
                    ),
                  );
                },
              ),
            ),
          ],
        ));
  }
}
